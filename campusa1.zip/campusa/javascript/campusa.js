require(['core/first'], function() {
    require(['theme_campusa/bootstrap', 'theme_campusa/anti_gravity', 'theme_campusa/custom', 'core/log'], function(bootstrap, ag, c, log) {
        log.debug('Campusa JavaScript initialised');
    });
});
