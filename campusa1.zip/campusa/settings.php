<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Campusa theme with the underlying Bootstrap theme.
 *
 * @package    theme
 * @subpackage campusa
 * @copyright  &copy; 2014-onwards G J Barnard in respect to modifications of the Clean theme.
 * @copyright  &copy; 2014-onwards Work undertaken for David Bogner of Edulabs.org.
 * @author     G J Barnard - gjbarnard at gmail dot com and {@link http://moodle.org/user/profile.php?id=442195}
 * @author     Based on code originally written by Mary Evans, Bas Brands, Stuart Lamour and David Scotson.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$settings = null;

defined('MOODLE_INTERNAL') || die;
if (is_siteadmin()) {
    global $CFG;
    if (file_exists("{$CFG->dirroot}/theme/campusa/admin_setting_configinteger.php")) {
        require_once($CFG->dirroot . '/theme/campusa/admin_setting_configinteger.php');
    } else if (!empty($CFG->themedir) && file_exists("{$CFG->themedir}/campusa/admin_setting_configinteger.php")) {
        require_once($CFG->themedir . '/campusa/admin_setting_configinteger.php');
    }

    $ADMIN->add('themes', new admin_category('theme_campusa', 'Campusa'));

    // Generic settings.
    $settingpage = new admin_settingpage('theme_campus_generic', get_string('genericsettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_generalheading', null,
        format_text(get_string('generalheadingdesc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Theme layout setting.
    $name = 'theme_campusa/themelayout';
    $title = get_string('themelayout', 'theme_campusa');
    $description = get_string('themelayoutdesc', 'theme_campusa');
    $default = 5;
    $choices = array(
        1 => get_string('themelayoutthreecolumns', 'theme_campusa'),
        2 => get_string('themelayoutthreecolumnsfplefttwo', 'theme_campusa'),
        3 => get_string('themelayoutthreecolumnsfprighttwo', 'theme_campusa'),
        4 => get_string('themelayoutlefttwocolumns', 'theme_campusa'),
        5 => get_string('themelayoutrighttwocolumns', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, but need to re-read config.php file, so needed.
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Login alternative URL setting.
    $name = 'theme_campusa/alternateloginurl';
    $title = get_string('alternateloginurl', 'theme_campusa');
    $description = get_string('alternateloginurldesc', 'theme_campusa');
    $default = 0;
    $sql = "SELECT DISTINCT h.id, h.wwwroot, h.name, a.sso_jump_url, a.name as application
            FROM {mnet_host} h
            JOIN {mnet_host2service} m ON h.id = m.hostid
            JOIN {mnet_service} s ON s.id = m.serviceid
            JOIN {mnet_application} a ON h.applicationid = a.id
            WHERE s.name = ? AND h.deleted = ? AND m.publish = ?";
    $params = array('sso_sp', 0, 1);

    if (!empty($CFG->mnet_all_hosts_id)) {
        $sql .= " AND h.id <> ?";
        $params[] = $CFG->mnet_all_hosts_id;
    }

    if ($hosts = $DB->get_records_sql($sql, $params)) {
        $choices = array();
        $choices[0] = 'notset';
        foreach ($hosts as $id => $host){
            $choices[$id] = $host->name;
        }    
    } else {
        $choices = array();
        $choices[0] = 'notset';
    }
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Hide local login on login page.
    $name = 'theme_campusa/hidelocallogin';
    $title = get_string('hidelocallogin', 'theme_campusa');
    $description = get_string('hidelocallogindesc', 'theme_campusa');
    $default = false;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Show login info header.
    $name = 'theme_campusa/showlogininfoheader';
    $title = get_string('showlogininfoheader', 'theme_campusa');
    $description = get_string('showlogininfoheaderdesc', 'theme_campusa');
    $default = true;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Show login info footer.
    $name = 'theme_campusa/showlogininfofooter';
    $title = get_string('showlogininfofooter', 'theme_campusa');
    $description = get_string('showlogininfofooterdesc', 'theme_campusa');
    $default = true;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Show headertoggle.
    $name = 'theme_campusa/showheadertoggle';
    $title = get_string('showheadertoggle', 'theme_campusa');
    $description = get_string('showheadertoggledesc', 'theme_campusa');
    $default = true;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Favicon file setting.
    $name = 'theme_campusa/favicon';
    $title = get_string('favicon', 'theme_campusa');
    $description = get_string('favicondesc', 'theme_campusa');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'favicon');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Custom CSS file.
    $name = 'theme_campusa/customcss';
    $title = get_string('customcss', 'theme_campusa');
    $description = get_string('customcssdesc', 'theme_campusa');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    $ADMIN->add('theme_campusa', $settingpage);

    // Look and feel settings.
    $settingpage = new admin_settingpage('theme_campus_landf', get_string('landfsettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_landfheading', null,
        format_text(get_string('landfheadingdesc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Page width maximum.
    $name = 'theme_campusa/pagewidthmax';
    $title = get_string('pagewidthmax', 'theme_campusa');
    $description = get_string('pagewidthmaxdesc', 'theme_campusa');
    $default = '1680';
    $choices = array(
        '1000' => new lang_string('px1000', 'theme_campusa'),
        '1200' => new lang_string('px1200', 'theme_campusa'),
        '1400' => new lang_string('px1400', 'theme_campusa'),
        '1680' => new lang_string('px1680', 'theme_campusa'),
        '100' => new lang_string('per100', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);
    $currentpagewidthmaxheaders = get_config('theme_campusa', 'pagewidthmax');  // Current value for other setting information descriptions below.
    if ($currentpagewidthmaxheaders == 100) { // Percentage value.
        $currentpagewidthmaxheaders = 1680; // Default for headers as need px max width.
    }

    // Heading font.
    $name = 'theme_campusa/headingfont';
    $title = get_string('headingfont', 'theme_campusa');
    $description = get_string('headingfontdesc', 'theme_campusa');
    $default = 'Roboto Condensed';
    $choices = array(
        'Droid Serif' => 'Droid Serif',
        'EB Garamond' => 'EB Garamond',
        'Jura' => 'Jura',
        'Nunito' => 'Nunito',
        'Roboto Condensed' => 'Roboto Condensed',
        'Source Sans Pro' => 'Source Sans Pro',
        'Titillium Text' => 'Titillium Text',
        'Ubuntu' => 'Ubuntu',
        'Vollkorn' => 'Vollkorn'
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Body font.
    $name = 'theme_campusa/bodyfont';
    $title = get_string('bodyfont', 'theme_campusa');
    $description = get_string('bodyfontdesc', 'theme_campusa');
    $default = 'Questrial';
    $choices = array(
        'Open Sans' => 'Open Sans',
        'Questrial' => 'Questrial',
        'Source Sans Pro' => 'Source Sans Pro'
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Text colour setting.
    $name = 'theme_campusa/textcolour';
    $title = get_string('textcolour', 'theme_campusa');
    $description = get_string('textcolourdesc', 'theme_campusa');
    $default = '#333333';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Link colour setting.
    $name = 'theme_campusa/linkcolour';
    $title = get_string('linkcolour', 'theme_campusa');
    $description = get_string('linkcolourdesc', 'theme_campusa');
    $default = '#333333';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Heading colour setting.
    $name = 'theme_campusa/headingcolour';
    $title = get_string('headingcolour', 'theme_campusa');
    $description = get_string('headingcolourdesc', 'theme_campusa');
    $default = '#555555';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Navbar text colour setting.
    $name = 'theme_campusa/navbartextcolour';
    $title = get_string('navbartextcolour', 'theme_campusa');
    $description = get_string('navbartextcolourdesc', 'theme_campusa');
    $default = '#190500';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block heading colour setting.
    $name = 'theme_campusa/blockheadingcolour';
    $title = get_string('blockheadingcolour', 'theme_campusa');
    $description = get_string('blockheadingcolourdesc', 'theme_campusa');
    $default = '#190300';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block heading background colour setting.
    $name = 'theme_campusa/blockheadingbackgroundcolour';
    $title = get_string('blockheadingbackgroundcolour', 'theme_campusa');
    $description = get_string('blockheadingbackgroundcolourdesc', 'theme_campusa');
    $default = '#a1d6de';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block background colour setting.
    $name = 'theme_campusa/blockbackgroundcolour';
    $title = get_string('blockbackgroundcolour', 'theme_campusa');
    $description = get_string('blockbackgroundcolourdesc', 'theme_campusa');
    $default = '#ffffff';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block border options.
    $name = 'theme_campusa/blockborderoptions';
    $title = get_string('blockborderoptions', 'theme_campusa');
    $description = get_string('blockborderoptionsdesc', 'theme_campusa');
    $default = 2;
    $choices = array(
        1 => new lang_string('blocknoborder', 'theme_campusa'),
        2 => new lang_string('blockborderall', 'theme_campusa'),
        3 => new lang_string('blockborderheader', 'theme_campusa'),
        4 => new lang_string('blockbordercontent', 'theme_campusa'),
        5 => new lang_string('blockborderthreelines', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block border colour setting.
    $name = 'theme_campusa/blockbordercolour';
    $title = get_string('blockbordercolour', 'theme_campusa');
    $description = get_string('blockbordercolourdesc', 'theme_campusa');
    $default = '#a1d6de';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block border thickness.
    $name = 'theme_campusa/blockborderthickness';
    $title = get_string('blockborderthickness', 'theme_campusa');
    $description = get_string('blockborderthicknessdesc', 'theme_campusa');
    $default = '2px';
    $choices = array(
        '1px' => new lang_string('px01', 'theme_campusa'),
        '2px' => new lang_string('px02', 'theme_campusa'),
        '3px' => new lang_string('px03', 'theme_campusa'),
        '4px' => new lang_string('px04', 'theme_campusa'),
        '5px' => new lang_string('px05', 'theme_campusa'),
        '6px' => new lang_string('px06', 'theme_campusa'),
        '7px' => new lang_string('px07', 'theme_campusa'),
        '8px' => new lang_string('px08', 'theme_campusa'),
        '9px' => new lang_string('px09', 'theme_campusa'),
        '10px' => new lang_string('px10', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Block border style.
    $name = 'theme_campusa/blockborderstyle';
    $title = get_string('blockborderstyle', 'theme_campusa');
    $description = get_string('blockborderstyledesc', 'theme_campusa');
    $default = 'solid';
    $choices = array(
        'none' => new lang_string('blockborderstylenone', 'theme_campusa'),
        'hidden' => new lang_string('blockborderstylehidden', 'theme_campusa'),
        'dotted' => new lang_string('blockborderstyledotted', 'theme_campusa'),
        'dashed' => new lang_string('blockborderstyledashed', 'theme_campusa'),
        'solid' => new lang_string('blockborderstylesolid', 'theme_campusa'),
        'double' => new lang_string('blockborderstyledouble', 'theme_campusa'),
        'groove' => new lang_string('blockborderstylegroove', 'theme_campusa'),
        'ridge' => new lang_string('blockborderstylenridge', 'theme_campusa'),
        'inset' => new lang_string('blockborderstyleninset', 'theme_campusa'),
        'outset' => new lang_string('blockborderstylenoutset', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Theme colour setting.
    $name = 'theme_campusa/themecolour';
    $title = get_string('themecolour', 'theme_campusa');
    $description = get_string('themecolourdesc', 'theme_campusa');
    $default = '#feee36';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Theme background colour setting.
    $name = 'theme_campusa/themebackgroundcolour';
    $title = get_string('themebackgroundcolour', 'theme_campusa');
    $description = get_string('themebackgroundcolourdesc', 'theme_campusa');
    $default = '#ffffff';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Small border radius.
    $name = 'theme_campusa/borderradiussmall';
    $title = get_string('borderradiussmall', 'theme_campusa');
    $description = get_string('borderradiussmall_desc', 'theme_campusa');
    $default = '3px';
    $choices = array(
        '0px' => new lang_string('px00', 'theme_campusa'),
        '1px' => new lang_string('px01', 'theme_campusa'),
        '2px' => new lang_string('px02', 'theme_campusa'),
        '3px' => new lang_string('px03', 'theme_campusa'),
        '4px' => new lang_string('px04', 'theme_campusa'),
        '5px' => new lang_string('px05', 'theme_campusa'),
        '6px' => new lang_string('px06', 'theme_campusa'),
        '7px' => new lang_string('px07', 'theme_campusa'),
        '8px' => new lang_string('px08', 'theme_campusa'),
        '9px' => new lang_string('px09', 'theme_campusa'),
        '10px' => new lang_string('px10', 'theme_campusa'),
        '11px' => new lang_string('px11', 'theme_campusa'),
        '12px' => new lang_string('px12', 'theme_campusa'),
        '13px' => new lang_string('px13', 'theme_campusa'),
        '14px' => new lang_string('px14', 'theme_campusa'),
        '15px' => new lang_string('px15', 'theme_campusa'),
        '16px' => new lang_string('px16', 'theme_campusa'),
        '17px' => new lang_string('px17', 'theme_campusa'),
        '18px' => new lang_string('px18', 'theme_campusa'),
        '19px' => new lang_string('px19', 'theme_campusa'),
        '20px' => new lang_string('px20', 'theme_campusa'),
        '21px' => new lang_string('px21', 'theme_campusa'),
        '22px' => new lang_string('px22', 'theme_campusa'),
        '23px' => new lang_string('px23', 'theme_campusa'),
        '24px' => new lang_string('px24', 'theme_campusa'),
        '25px' => new lang_string('px25', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Medium border radius.
    $name = 'theme_campusa/borderradiusmedium';
    $title = get_string('borderradiusmedium', 'theme_campusa');
    $description = get_string('borderradiusmedium_desc', 'theme_campusa');
    $default = '6px';
    $choices = array(
        '0px' => new lang_string('px00', 'theme_campusa'),
        '1px' => new lang_string('px01', 'theme_campusa'),
        '2px' => new lang_string('px02', 'theme_campusa'),
        '3px' => new lang_string('px03', 'theme_campusa'),
        '4px' => new lang_string('px04', 'theme_campusa'),
        '5px' => new lang_string('px05', 'theme_campusa'),
        '6px' => new lang_string('px06', 'theme_campusa'),
        '7px' => new lang_string('px07', 'theme_campusa'),
        '8px' => new lang_string('px08', 'theme_campusa'),
        '9px' => new lang_string('px09', 'theme_campusa'),
        '10px' => new lang_string('px10', 'theme_campusa'),
        '11px' => new lang_string('px11', 'theme_campusa'),
        '12px' => new lang_string('px12', 'theme_campusa'),
        '13px' => new lang_string('px13', 'theme_campusa'),
        '14px' => new lang_string('px14', 'theme_campusa'),
        '15px' => new lang_string('px15', 'theme_campusa'),
        '16px' => new lang_string('px16', 'theme_campusa'),
        '17px' => new lang_string('px17', 'theme_campusa'),
        '18px' => new lang_string('px18', 'theme_campusa'),
        '19px' => new lang_string('px19', 'theme_campusa'),
        '20px' => new lang_string('px20', 'theme_campusa'),
        '21px' => new lang_string('px21', 'theme_campusa'),
        '22px' => new lang_string('px22', 'theme_campusa'),
        '23px' => new lang_string('px23', 'theme_campusa'),
        '24px' => new lang_string('px24', 'theme_campusa'),
        '25px' => new lang_string('px25', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Large border radius.
    $name = 'theme_campusa/borderradiuslarge';
    $title = get_string('borderradiuslarge', 'theme_campusa');
    $description = get_string('borderradiuslarge_desc', 'theme_campusa');
    $default = '8px';
    $choices = array(
        '0px' => new lang_string('px00', 'theme_campusa'),
        '1px' => new lang_string('px01', 'theme_campusa'),
        '2px' => new lang_string('px02', 'theme_campusa'),
        '3px' => new lang_string('px03', 'theme_campusa'),
        '4px' => new lang_string('px04', 'theme_campusa'),
        '5px' => new lang_string('px05', 'theme_campusa'),
        '6px' => new lang_string('px06', 'theme_campusa'),
        '7px' => new lang_string('px07', 'theme_campusa'),
        '8px' => new lang_string('px08', 'theme_campusa'),
        '9px' => new lang_string('px09', 'theme_campusa'),
        '10px' => new lang_string('px10', 'theme_campusa'),
        '11px' => new lang_string('px11', 'theme_campusa'),
        '12px' => new lang_string('px12', 'theme_campusa'),
        '13px' => new lang_string('px13', 'theme_campusa'),
        '14px' => new lang_string('px14', 'theme_campusa'),
        '15px' => new lang_string('px15', 'theme_campusa'),
        '16px' => new lang_string('px16', 'theme_campusa'),
        '17px' => new lang_string('px17', 'theme_campusa'),
        '18px' => new lang_string('px18', 'theme_campusa'),
        '19px' => new lang_string('px19', 'theme_campusa'),
        '20px' => new lang_string('px20', 'theme_campusa'),
        '21px' => new lang_string('px21', 'theme_campusa'),
        '22px' => new lang_string('px22', 'theme_campusa'),
        '23px' => new lang_string('px23', 'theme_campusa'),
        '24px' => new lang_string('px24', 'theme_campusa'),
        '25px' => new lang_string('px25', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Well background setting.
    $name = 'theme_campusa/wellbackgroundcolour';
    $title = get_string('wellbackgroundcolour', 'theme_campusa');
    $description = get_string('wellbackgroundcolourdesc', 'theme_campusa');
    $default = '#FFE7AA';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Alert info text setting.
    $name = 'theme_campusa/alertinfotextcolour';
    $title = get_string('alertinfotextcolour', 'theme_campusa');
    $description = get_string('alertinfotextcolourdesc', 'theme_campusa');
    $default = '#3A87AD';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Alert info background setting.
    $name = 'theme_campusa/alertinfobackgroundcolour';
    $title = get_string('alertinfobackgroundcolour', 'theme_campusa');
    $description = get_string('alertinfobackgroundcolourdesc', 'theme_campusa');
    $default = '#D9EDF7';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    $ADMIN->add('theme_campusa', $settingpage);

    // Header settings.
    $settingpage = new admin_settingpage('theme_campus_header', get_string('headersettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_headerheading', null,
        format_text(get_string('headerheadingdesc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Show page heading.
    $name = 'theme_campusa/showpageheading';
    $title = get_string('showpageheading', 'theme_campusa');
    $description = get_string('showpageheadingdesc', 'theme_campusa');
    $default = false;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Invert Navbar to dark background.
    $name = 'theme_campusa/invert';
    $title = get_string('invert', 'theme_campusa');
    $description = get_string('invertdesc', 'theme_campusa');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Navbar type.
    $name = 'theme_campusa/navbartype';
    $title = get_string('navbartype', 'theme_campusa');
    $description = get_string('navbartypedesc', 'theme_campusa');
    $default = 1;
    $choices = array(
        1 => new lang_string('standardnavbar', 'theme_campusa'),
        2 => new lang_string('fancynavbar', 'theme_campusa')
    );
    // No CSS change, so no need to reset caches.
    $settingpage->add(new admin_setting_configselect($name, $title, $description, $default, $choices));

    // Page heading range.
    $name = 'theme_campusa/navbarpageheadingmax';
    $title = get_string('navbarpageheadingmax', 'theme_campusa');
    $default = 200;
    $lower = 40;
    $upper = 400;
    $description = get_string('navbarpageheadingmaxdesc', 'theme_campusa', array('lower' => $lower, 'upper' => $upper));
    $setting = new admin_setting_configinteger($name, $title, $description, $default, $lower, $upper);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Sticky navbar.
    $name = 'theme_campusa/stickynavbar';
    $title = get_string('stickynavbar', 'theme_campusa');
    $description = get_string('stickynavbardesc', 'theme_campusa');
    $default = true;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Frontpage header settings.
    $settingpage->add(new admin_setting_heading('theme_campus_frontpage', get_string('frontpageheadersettings', 'theme_campusa'),
            format_text(get_string('frontpageheadersettings_desc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Have a custom front page header.
    $name = 'theme_campusa/usefrontpageheader';
    $title = get_string('usefrontpageheader', 'theme_campusa');
    $description = get_string('usefrontpageheaderdesc', 'theme_campusa');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 1);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Frontpage layout setting.
    $name = 'theme_campusa/frontpagelayout';
    $title = get_string('frontpagelayout', 'theme_campusa');
    $description = get_string('frontpagelayoutdesc', 'theme_campusa');
    $default = 'flexlayout';
    $choices = array(
        'absolutelayout' => new lang_string('layoutontop', 'theme_campusa'),
        'flexlayout' => new lang_string('layoutonside', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Sticky navbar.
    $name = 'theme_campusa/frontpagestickynavbar';
    $title = get_string('frontpagestickynavbar', 'theme_campusa');
    $description = get_string('frontpagestickynavbardesc', 'theme_campusa');
    $default = true;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Logo file setting.
    $name = 'theme_campusa/frontpagelogo';
    $title = get_string('frontpagelogo', 'theme_campusa');
    $description = get_string('frontpagelogodesc', 'theme_campusa', array('pagewidthmax' => $currentpagewidthmaxheaders));
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'frontpagelogo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Logo file setting on small devices.
    $name = 'theme_campusa/frontpageresponsivelogo';
    $title = get_string('frontpageresponsivelogo', 'theme_campusa');
    $description = get_string('frontpageresponsivelogodesc', 'theme_campusa');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'frontpageresponsivelogo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Logo position setting.
    $name = 'theme_campusa/frontpagelogoposition';
    $title = get_string('frontpagelogoposition', 'theme_campusa');
    $description = get_string('frontpagelogopositiondesc', 'theme_campusa');
    $default = 2;
    $choices = array(
        1 => new lang_string('imageleft', 'theme_campusa'),
        2 => new lang_string('imageright', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Background image file setting.
    $name = 'theme_campusa/frontpagebackgroundimage';
    $title = get_string('frontpagebackgroundimage', 'theme_campusa');
    $description = get_string('frontpagebackgroundimagedesc', 'theme_campusa', array('pagewidthmax' => $currentpagewidthmaxheaders));
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'frontpagebackgroundimage');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Background image file setting on small devices.
    $name = 'theme_campusa/frontpageresponsivebackgroundimage';
    $title = get_string('frontpageresponsivebackgroundimage', 'theme_campusa');
    $description = get_string('frontpageresponsivebackgroundimagedesc', 'theme_campusa');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'frontpageresponsivebackgroundimage');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    $settingpage->add(new admin_setting_heading('theme_campus_coursecategory', get_string('coursecategoryhavecustomheaderheader', 'theme_campusa'),
            format_text(get_string('coursecategoryhavecustomheaderheader_desc', 'theme_campusa'), FORMAT_MARKDOWN)));

    if (file_exists("{$CFG->dirroot}/theme/campusa/campus-lib.php")) {
        include_once($CFG->dirroot . '/theme/campusa/campus-lib.php');
    } else if (!empty($CFG->themedir) && file_exists("{$CFG->themedir}/campusa/campus-lib.php")) {
        include_once($CFG->themedir . '/campusa/campus-lib.php');
    }
    $campuscategorytree = theme_campus_get_top_level_categories();
    foreach($campuscategorytree as $key => $value){
        // Have a custom header for the course category.
        $name = 'theme_campusa/coursecategoryhavecustomheader'.$key;
        $title = get_string('coursecategoryhavecustomheader', 'theme_campusa', array('categoryname' => $value));
        $description = get_string('coursecategoryhavecustomheaderdesc', 'theme_campusa', array('categoryname' => $value));
        $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
        $setting->set_updatedcallback('theme_reset_all_caches');  // CSS change to generate extra selectors if turning on for a new category for the first time.
        $settingpage->add($setting);
    }

    $ADMIN->add('theme_campusa', $settingpage);

    // Course category header settings.
    $settingpage = new admin_settingpage('theme_campus_category_header', get_string('coursecategoryheadersettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_category_header_heading', null,
        format_text(get_string('coursecategoryheadersettings_desc', 'theme_campusa'), FORMAT_MARKDOWN)));

    $havecategories = false;
    foreach($campuscategorytree as $key => $value){
        $havecustomheader = get_config('theme_campusa', 'coursecategoryhavecustomheader'.$key);
        if (empty($havecustomheader)) {
            continue;
        }
        $havecategories = true;

        $name = 'theme_campusa/coursecategoryheading'.$key;
        $heading = get_string('coursecategoryheading', 'theme_campusa', array('categoryname' => $value));
        $information = '';
        $setting = new admin_setting_heading($name, $heading, $information);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Sticky navbar.
        $name = 'theme_campusa/coursecategorystickynavbar'.$key;
        $title = get_string('coursecategorystickynavbar', 'theme_campusa');
        $description = get_string('coursecategorystickynavbardesc', 'theme_campusa', array('categoryname' => $value));
        $default = true;
        $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Background colour.
        $name = 'theme_campusa/coursecategorybgcolour'.$key;
        $title = get_string('coursecategorybgcolour', 'theme_campusa');
        $description = get_string('coursecategorybgcolourdesc', 'theme_campusa', array('categoryname' => $value));
        $default = '#11847D';
        $previewconfig = NULL;
        $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Course category layout setting.
        $name = 'theme_campusa/coursecategorylayout'.$key;
        $title = get_string('coursecategorylayout', 'theme_campusa');
        $description = get_string('coursecategorylayoutdesc', 'theme_campusa');
        $default = 'flexlayout';
        $choices = array(
            'absolutelayout' => new lang_string('layoutontop', 'theme_campusa'),
            'flexlayout' => new lang_string('layoutonside', 'theme_campusa')
        );
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Logo file setting.
        $name = 'theme_campusa/coursecategorylogo'.$key;
        $title = get_string('coursecategorylogo', 'theme_campusa');
        $description = get_string('coursecategorylogodesc', 'theme_campusa', array('pagewidthmax' => $currentpagewidthmaxheaders));
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'coursecategorylogo'.$key);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Logo file setting on small devices.
        $name = 'theme_campusa/coursecategoryresponsivelogo'.$key;
        $title = get_string('coursecategoryresponsivelogo', 'theme_campusa');
        $description = get_string('coursecategoryresponsivelogodesc', 'theme_campusa');
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'coursecategoryresponsivelogo'.$key);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Logo position setting.
        $name = 'theme_campusa/coursecategorylogoposition'.$key;
        $title = get_string('coursecategorylogoposition', 'theme_campusa');
        $description = get_string('coursecategorylogopositiondesc', 'theme_campusa');
        $default = 2;
        $choices = array(
            1 => new lang_string('imageleft', 'theme_campusa'),
            2 => new lang_string('imageright', 'theme_campusa')
        );
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Background image file setting.
        $name = 'theme_campusa/coursecategorybackgroundimage'.$key;
        $title = get_string('coursecategorybackgroundimage', 'theme_campusa');
        $description = get_string('coursecategorybackgroundimagedesc', 'theme_campusa', array('pagewidthmax' => $currentpagewidthmaxheaders));
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'coursecategorybackgroundimage'.$key);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);

        // Background image file setting on small devices.
        $name = 'theme_campusa/coursecategoryresponsivebackgroundimage'.$key;
        $title = get_string('coursecategoryresponsivebackgroundimage', 'theme_campusa');
        $description = get_string('coursecategoryresponsivebackgroundimagedesc', 'theme_campusa');
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'coursecategoryresponsivebackgroundimage'.$key);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $settingpage->add($setting);
    }
    if ($havecategories == false) {
        $settingpage->add(new admin_setting_heading('theme_campus_category_header_none_heading', null,
            format_text(get_string('coursecategoryhavecustomheadernone', 'theme_campusa'), FORMAT_MARKDOWN)));
    }

    $ADMIN->add('theme_campusa', $settingpage);

    // Footer settings.
    $settingpage = new admin_settingpage('theme_campus_footer', get_string('footersettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_footerheading', null,
        format_text(get_string('footerheadingdesc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Number of footer blocks.
    $name = 'theme_campusa/numfooterblocks';
    $title = get_string('numfooterblocks','theme_campusa');
    $description = get_string('numfooterblocksdesc', 'theme_campusa');
    $choices = array(
        1 => new lang_string('one', 'theme_campusa'),
        2 => new lang_string('two', 'theme_campusa'),
        3 => new lang_string('three', 'theme_campusa'),
        4 => new lang_string('four', 'theme_campusa')
    );
    $default = 2;
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Footnote setting.
    $name = 'theme_campusa/footnote';
    $title = get_string('footnote', 'theme_campusa');
    $description = get_string('footnotedesc', 'theme_campusa');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    $ADMIN->add('theme_campusa', $settingpage);

    // Carousel settings.
    $settingpage = new admin_settingpage('theme_campus_carousel', get_string('carouselsettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_carouselheading', null,
        format_text(get_string('carouselsettingsdesc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Slider position setting.
    $name = 'theme_campusa/sliderposition';
    $title = get_string('sliderposition', 'theme_campusa');
    $description = get_string('sliderpositiondesc', 'theme_campusa');
    $default = 1;
    $choices = array(
        1 => new lang_string('sliderpositionheader', 'theme_campusa'),
        2 => new lang_string('sliderpositionpage', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Autoplay.
    $name = 'theme_campusa/carouselautoplay';
    $title = get_string('carouselautoplay', 'theme_campusa');
    $description = get_string('carouselautoplaydesc', 'theme_campusa');
    $default = 2;
    $choices = array(
        1 => new lang_string('no'),   // No.
        2 => new lang_string('yes')   // Yes.
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Slide interval.
    $name = 'theme_campusa/slideinterval';
    $title = get_string('slideinterval', 'theme_campusa');
    $default = 5000;
    $lower = 1000;
    $upper = 100000;
    $description = get_string('slideintervaldesc', 'theme_campusa', array('lower' => $lower, 'upper' => $upper));
    $setting = new admin_setting_configinteger($name, $title, $description, $default, $lower, $upper);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Carousel text colour setting.
    $name = 'theme_campusa/carouseltextcolour';
    $title = get_string('carouseltextcolour', 'theme_campusa');
    $description = get_string('carouseltextcolourdesc', 'theme_campusa');
    $default = '#ffffff';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Show caption centred.
    $name = 'theme_campusa/slidecaptioncentred';
    $title = get_string('slidecaptioncentred', 'theme_campusa');
    $description = get_string('slidecaptioncentreddesc', 'theme_campusa');
    $default = false;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default, true, false);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Slide button colour setting.
    $name = 'theme_campusa/slidebuttoncolour';
    $title = get_string('slidebuttoncolour', 'theme_campusa');
    $description = get_string('slidebuttoncolourdesc', 'theme_campusa');
    $default = '#30add1';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    // Slide button hover colour setting.
    $name = 'theme_campusa/slidebuttonhovercolour';
    $title = get_string('slidebuttonhovercolour', 'theme_campusa');
    $description = get_string('slidebuttonhovercolourdesc', 'theme_campusa');
    $default = '#217a94';
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settingpage->add($setting);

    $ADMIN->add('theme_campusa', $settingpage);

    // Frontpage carousel settings.
    $settingpage = new admin_settingpage('theme_campus_frontpage_carousel', get_string('frontpagecarouselsettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_carousel_frontpage', null,
            format_text(get_string('frontpagecarouselsettings_desc', 'theme_campusa'), FORMAT_MARKDOWN)));

    // Status.
    $name = 'theme_campusa/frontpagecarouselstatus';
    $title = get_string('carouselstatus', 'theme_campusa');
    $description = get_string('carouselstatus_desc', 'theme_campusa');
    $default = 1;
    $choices = array(
        1 => new lang_string('draft', 'theme_campusa'),
        2 => new lang_string('published', 'theme_campusa')
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    // Number of slides.
    $name = 'theme_campusa/numberofslidesforfrontpage';
    $title = get_string('numberofslides', 'theme_campusa');
    $default = 0;
    $lower = 0;
    $upper = 6;
    $description = get_string('numberofslidesdesc', 'theme_campusa', array('lower' => $lower, 'upper' => $upper));
    $setting = new admin_setting_configinteger($name, $title, $description, $default, $lower, $upper);
    // No CSS change, so no need to reset caches.
    $settingpage->add($setting);

    $numberofslides = get_config('theme_campusa', 'numberofslidesforfrontpage');
    for ($i = 1; $i <= $numberofslides; $i++) {
        // This is the information.
        $name = 'theme_campusa/frontpageslide'.$i.'info';
        $heading = get_string('slideno', 'theme_campusa', array('slide' => $i));
        $information = get_string('slidenodesc', 'theme_campusa', array('slide' => $i));
        $setting = new admin_setting_heading($name, $heading, $information);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Title.
        $name = 'theme_campusa/frontpage' . $i .'title';
        $title = get_string('slidetitle', 'theme_campusa');
        $description = get_string('slidetitledesc', 'theme_campusa');
        $default = '';
        $setting = new admin_setting_configtext($name, $title, $description, $default);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Image.
        $name = 'theme_campusa/frontpage'.$i.'image';
        $title = get_string('slideimage', 'theme_campusa');
        $description = get_string('slideimagedesc', 'theme_campusa');
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'frontpage'.$i.'image');
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Caption text.
        $name = 'theme_campusa/frontpage'. $i . 'caption';
        $title = get_string('slidecaption', 'theme_campusa');
        $description = get_string('slidecaptiondesc', 'theme_campusa');
        $default = '';
        $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_TEXT);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Link.
        $name = 'theme_campusa/frontpage' . $i .'link';
        $title = get_string('slidelink', 'theme_campusa');
        $description = get_string('slidelinkdesc', 'theme_campusa');
        $default = '';
        $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Link target.
        $name = 'theme_campusa/frontpage' . $i .'linktarget';
        $title = get_string('slidelinktarget', 'theme_campusa');
        $description = get_string('slidelinktargetdesc', 'theme_campusa');
        $default = 1;
        $choices = array(
            '_self' => new lang_string('slidelinktargetself', 'theme_campusa'),
            '_blank' => new lang_string('slidelinktargetblank', 'theme_campusa')
        );
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);
    }

    $ADMIN->add('theme_campusa', $settingpage);

     // Course category carousel settings.
    $settingpage = new admin_settingpage('theme_campus_category_carousel', get_string('coursecategorycarouselsettings', 'theme_campusa'));
    $settingpage->add(new admin_setting_heading('theme_campus_carousel_coursecategory', null,
            format_text(get_string('coursecategorycarouselsettings_desc', 'theme_campusa'), FORMAT_MARKDOWN)));

    $campuscategorytree = theme_campus_get_top_level_categories();
    foreach($campuscategorytree as $key => $value){
        $name = 'theme_campusa/coursecategoryheading'.$key;
        $heading = get_string('coursecategoryheading', 'theme_campusa', array('categoryname' => $value));
        $information = '';
        $setting = new admin_setting_heading($name, $heading, $information);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Status.
        $name = 'theme_campusa/coursecategorycarouselstatus'.$key;
        $title = get_string('carouselstatus', 'theme_campusa');
        $description = get_string('carouselstatus_desc', 'theme_campusa');
        $default = 1;
        $choices = array(
            1 => new lang_string('draft', 'theme_campusa'),
            2 => new lang_string('published', 'theme_campusa')
        );
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        // Number of slides.
        $name = 'theme_campusa/numberofslidesforcategory'.$key;
        $title = get_string('numberofslides', 'theme_campusa');
        $default = 0;
        $lower = 0;
        $upper = 6;
        $description = get_string('numberofslidesdesc', 'theme_campusa', array('lower' => $lower, 'upper' => $upper));
        $setting = new admin_setting_configinteger($name, $title, $description, $default, $lower, $upper);
        // No CSS change, so no need to reset caches.
        $settingpage->add($setting);

        $numberofslides = get_config('theme_campusa', 'numberofslidesforcategory'.$key);
        for ($i = 1; $i <= $numberofslides; $i++) {
            // This is the information.
            $name = 'theme_campusa/coursecategory'.$key.'_slide'.$i.'info';
            $heading = get_string('slideno', 'theme_campusa', array('slide' => $i));
            $information = get_string('slidenodesc', 'theme_campusa', array('slide' => $i));
            $setting = new admin_setting_heading($name, $heading, $information);
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);

            // Title.
            $name = 'theme_campusa/coursecategory'.$key.'_' . $i .'title';
            $title = get_string('slidetitle', 'theme_campusa');
            $description = get_string('slidetitledesc', 'theme_campusa');
            $default = '';
            $setting = new admin_setting_configtext($name, $title, $description, $default);
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);

            // Image.
            $name = 'theme_campusa/coursecategory'.$key.'_'.$i.'image';
            $title = get_string('slideimage', 'theme_campusa');
            $description = get_string('slideimagedesc', 'theme_campusa');
            $setting = new admin_setting_configstoredfile($name, $title, $description, 'coursecategory'.$key.'_'.$i.'image');
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);

            // Caption text.
            $name = 'theme_campusa/coursecategory'.$key.'_'. $i . 'caption';
            $title = get_string('slidecaption', 'theme_campusa');
            $description = get_string('slidecaptiondesc', 'theme_campusa');
            $default = '';
            $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_TEXT);
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);

            // Link.
            $name = 'theme_campusa/coursecategory'.$key.'_' . $i .'link';
            $title = get_string('slidelink', 'theme_campusa');
            $description = get_string('slidelinkdesc', 'theme_campusa');
            $default = '';
            $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);

            // Link target.
            $name = 'theme_campusa/coursecategory'.$key.'_' . $i .'linktarget';
            $title = get_string('slidelinktarget', 'theme_campusa');
            $description = get_string('slidelinktargetdesc', 'theme_campusa');
            $default = 1;
            $choices = array(
                '_self' => new lang_string('slidelinktargetself', 'theme_campusa'),
                '_blank' => new lang_string('slidelinktargetblank', 'theme_campusa')
            );
            $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
            // No CSS change, so no need to reset caches.
            $settingpage->add($setting);
        }
    }

    $ADMIN->add('theme_campusa', $settingpage);

    // Social links page....
    // Number of social links.
    $name = 'theme_campusa/numberofsociallinks';
    $title = get_string('numberofsociallinks', 'theme_campusa');
    $description = get_string('numberofsociallinks_desc', 'theme_campusa');
    $default = 2;
    $choices = array(
        0 => '0',
        1 => '1',
        2 => '2',
        3 => '3',
        4 => '4',
        5 => '5',
        6 => '6',
        7 => '7',
        8 => '8',
        9 => '9',
        10 => '10',
        11 => '11',
        12 => '12',
        13 => '13',
        14 => '14',
        15 => '15',
        16 => '16'
    );

    $socialsettings = new admin_settingpage('theme_campus_social', get_string('socialheading', 'theme_campusa'));
    $socialsettings->add(new admin_setting_heading('theme_campus_social', get_string('socialheadingsub', 'theme_campusa'),
            format_text(get_string('socialheadingdesc', 'theme_campusa'), FORMAT_MARKDOWN)));
    $socialsettings->add(new admin_setting_configselect($name, $title, $description, $default, $choices));

    $numberofsociallinks = get_config('theme_campusa', 'numberofsociallinks');
    for ($i = 1; $i <= $numberofsociallinks; $i++) {
        // Social url setting.
        $name = 'theme_campusa/social'.$i;
        $title = get_string('socialnetworklink', 'theme_campusa').$i;
        $description = get_string('socialnetworklink_desc', 'theme_campusa').$i;
        $default = '';
        $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $socialsettings->add($setting);

        // Social icon setting.
        $name = 'theme_campusa/socialicon'.$i;
        $title = get_string('socialnetworkicon', 'theme_campusa').$i;
        $description = get_string('socialnetworkicon_desc', 'theme_campusa').$i;
        $default = 'globe';
        $choices = array(
            'dropbox' => 'Dropbox',
            'facebook-square' => 'Facebook',
            'flickr' => 'Flickr',
            'github' => 'Github',
            'google-plus-square' => 'Google Plus',
            'instagram' => 'Instagram',
            'linkedin-square' => 'Linkedin',
            'pinterest-square' => 'Pinterest',
            'skype' => 'Skype',
            'tumblr-square' => 'Tumblr',
            'twitter-square' => 'Twitter',
            'users' => 'Unlisted',
            'vimeo-square' => 'Vimeo',
            'vk' => 'Vk',
            'globe' => 'Website',
            'youtube-square' => 'YouTube'
        );
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $socialsettings->add($setting);
    }

    $ADMIN->add('theme_campusa', $socialsettings);
}
